#include<iostream>
#include<string>
using namespace std;

int main()
{
	int ung[10], ada, gea, dadda, baba, sugi;
	char apa[10][25];
	string earl;
	
	cout<<"Masukkan kalimat kalian= ";
	getline(cin, earl);
	ada=earl.length();
	
	baba=earl.size();\
	
	dadda=0;
	ung[dadda]=0;
	for(gea=0; gea<baba; gea++)
	{
		apa[dadda][gea]=earl[gea];
		ung[dadda]++;
		if(apa[dadda][gea]==' ')
		{
			dadda++;
		}
	}
	
	dadda+=2;
	baba--;
	for(gea=0; gea<=dadda; gea++)
	{
		ada=ung[gea];
		sugi=ada;
		while(sugi>=0)
		{
			cout<<apa[gea][sugi];
			sugi--;
		}
	}
}